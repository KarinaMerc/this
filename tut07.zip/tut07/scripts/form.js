// JavaScript Document

// alert("Hello world!");

// Array Declatarions
	var inputArray = document.getElementsByTagName("input");
	var numInputs = inputArray.length;

function formDetails(){
	// CUSTOMER INQUIRY OBJECT
	const contactObj = {
		firstName: 	document.contactForm.fname.value,
		surname: 	document.contactForm.surname.value,
		email: 		document.contactForm.email.value,
		contact: 	document.contactForm.contact.value,
		date: 		document.contactForm.date.value,
		media: 		document.contactForm.media.value,
		message: 	document.contactForm.message.value, 
		showDetails(){
			var msgDetails = 'Thanks, <strong>' + this.firstName + '</strong>. Please confirm if your details are correct: <br><br><strong>Email:</strong> ' + this.email + '<br><br><strong>Message:</strong> <br>' + this.message;
			
			return msgDetails;
		}

	}; // eng of contactObj
		
	const customer = Object.create(contactObj);
	
	if(customer.firstName!=""&&customer.email!=""&&customer.message!=""){
		document.getElementById("overlay").style.display = "block";
		document.getElementById("msgetails").innerHTML = customer.showDetails()
	}

}

function closeOverlay(){
	document.getElementById("overlay").style.display = "none";	
}

function validateForm(message){
	document.getElementById("contactForm").submit();
}

function test(){
	var message;
	var firstName = document.getElementById("fname").value;
	var email = document.contactForm.email;
	
	// Outputting total number of <input> elements on the page.
	alert("This page has " + numInputs + " input elements.");

	// alert(unputArray[2].value);
	
	message = "Your contact details are: \n";
	// message = message + firstName + "\";
	
	// alert(email);
	
	if(email.value!=""){
	    // remove empty-field-message
		document.getElementsByClassName("empty-field-message")[0].style.display="none";
	}else{
	    // display empty-field-message
		document.getElementsByClassName("empty-field-message")[0].style.display="inline";
		document.getElementsByClassName("empty-field-message")[0].style.color="FF0000";
	   }
	
	for(var i=0;i<numInputs;i++){
		if(inputArray[i].type!="checkbox"&&inputArray[i].type!="button"&& 	inputArray[i].type!="reset"){
			message = message + "\n" + inputArray[i].id + " = " + inputArray[i].value;
		}
	}
	alert(message);
	
	formDetails();
	
	
	} // END OF TEST() FUNCTION